package com.javatpoint.server.main;

//@SpringBootTest
class JenkinsJobV3ApplicationTests {


}
